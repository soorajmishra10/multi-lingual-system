Styling.js
=========

Styling Google Translate website plugin. View preview [here].

First, [add Google Translate plugin] to your website and then add Stylinggt.js.

For now, you can do the next:

  - Remove left icon.
  - Change left icon.
  - Change center text.
  - Change right icon.
  - Change border color.
  - Change background color.
  - Change text color.
  - Change text size.


> To make a default style, uncomment the line 5 of example.js to use 'defaultStyle' funciton.

[here]: http://stylinggt.azurewebsites.net
[add Google Translate plugin]: http://translate.google.com/translate_tools
